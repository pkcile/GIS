﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 操作步骤
{
    public partial class _2画起始位置方块 : Form
    {
        public _2画起始位置方块()
        {
            InitializeComponent();
        }
        List<int> x = new List<int>();//定义蛇的x点，y点坐标//**********2添加项***********
        List<int> y = new List<int>();//**********2添加项***********

        private void btnBegin_Click(object sender, EventArgs e)
        {
            //将整个框子画出
            Graphics g = panel1.CreateGraphics();//定义画布
            Pen pen1 = new Pen(Color.White, 8);//定义画笔（颜色，粗细）
            for (int i = 0; i <= 16; i++)//代表横线17条线，竖线17条线，形成16*16个格子
            {
                g.DrawLine(pen1, 0, 4 + 24 * i, 392, 4 + 24 * i);//画横线 392=(8+16)*16+8 。 8代表框子的宽度，16代表接下来要定义的格子的宽度
                g.DrawLine(pen1, 4 + 24 * i, 0, 4 + 24 * i, 392);//画竖线
            }
            //画出起始出现的两个方块，（数目随意定）//**********2添加项***********
            //例如：我们定义两个起始点为（8，8）,(32,8)//**********2添加项***********
            x.Add(8); y.Add(8);//(8,8),即（x[0]，y[0])点//**********2添加项***********
            x.Add(32); y.Add(8);//(32,8),即（x[1]，y[1])点//**********2添加项***********
            SolidBrush brush1 = new SolidBrush(Color.Red);//**********2添加项***********
            g.FillRectangle(brush1, x[0], y[0], 16, 16);//**********2添加项***********
            g.FillRectangle(brush1, x[1], y[1], 16, 16);//**********2添加项***********
            //我们设定蛇头为（x[0]，y[0])点所在方块//**********2添加项***********
        }


        private void _2画起始位置方块_Load(object sender, EventArgs e)
        {

        }
    }
}
