﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 操作步骤
{
    public partial class _4产生随机食物 : Form
    {
        public _4产生随机食物()
        {
            InitializeComponent();
        }
        List<int> x = new List<int>();//定义蛇的x点，y点坐标
        List<int> y = new List<int>();
        List<int> xfood = new List<int>(); List<int> yfood = new List<int>();//定义食物的x,y坐标//**********4产生随机食物中添加内容*************
        private void button1_Click(object sender, EventArgs e)//**********4产生随机食物中添加内容，还不能增加蛇本身*************
        {
            Random random1 = new Random();
            //random1.Next(0,16);
            //将随机产生的食物坐标存入；
            xfood.Add(8 + random1.Next(0, 16) * 24);
            yfood.Add(8 + random1.Next(0, 16) * 24);
            //将食物显现出来
            Graphics g1 = panel1.CreateGraphics();
            SolidBrush brush2 = new SolidBrush(Color.Red);//定义黑色的刷子
            g1.FillRectangle(brush2, xfood[xfood.Count - 1], yfood[xfood.Count - 1], 16, 16);//即选中在随机食物数组中的最后一组显现出来
      
        }

        private void btnBegin_Click(object sender, EventArgs e)
        {
            //将整个框子画出
            Graphics g = panel1.CreateGraphics();//定义画布
            Pen pen1 = new Pen(Color.White, 8);//定义画笔（颜色，粗细）
            for (int i = 0; i <= 16; i++)//代表横线17条线，竖线17条线，形成16*16个格子
            {
                g.DrawLine(pen1, 0, 4 + 24 * i, 392, 4 + 24 * i);//画横线 392=(8+16)*16+8 。 8代表框子的宽度，16代表接下来要定义的格子的宽度
                g.DrawLine(pen1, 4 + 24 * i, 0, 4 + 24 * i, 392);//画竖线
            }
            //画出起始出现的两个方块，（数目随意定）
            //例如：我们定义两个起始点为（8，8）,(32,8)
            x.Add(8); y.Add(8);//(8,8),即（x[0]，y[0])点
            x.Add(32); y.Add(8);//(32,8),即（x[1]，y[1])点
            SolidBrush brush1 = new SolidBrush(Color.Red);
            g.FillRectangle(brush1, x[0], y[0], 16, 16);
            g.FillRectangle(brush1, x[1], y[1], 16, 16);
            //我们设定蛇头为（x[0]，y[0])点所在方块

        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            //清除蛇
            Graphics g1 = panel1.CreateGraphics();
            SolidBrush brush2 = new SolidBrush(Color.Black);//定义黑色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush2, x[i], y[i], 16, 16);
            }
            //移动的内在逻辑
            for (int i = x.Count - 1; i > 0; i--)//除蛇头部分移动
            {
                x[i] = x[i - 1];
                y[i] = y[i - 1];
            }

            y[0] = y[0] - 24;//蛇头移动
            //画出蛇
            SolidBrush brush3 = new SolidBrush(Color.Red);//定义红色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush3, x[i], y[i], 16, 16);
            }
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            //清除蛇
            Graphics g1 = panel1.CreateGraphics();
            SolidBrush brush2 = new SolidBrush(Color.Black);//定义黑色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush2, x[i], y[i], 16, 16);
            }
            //移动的内在逻辑
            for (int i = x.Count - 1; i > 0; i--)//除蛇头部分移动
            {
                x[i] = x[i - 1];
                y[i] = y[i - 1];
            }

            y[0] = y[0] + 24;//蛇头移动
            //画出蛇
            SolidBrush brush3 = new SolidBrush(Color.Red);//定义红色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush3, x[i], y[i], 16, 16);
            }
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            //清除蛇
            Graphics g1 = panel1.CreateGraphics();
            SolidBrush brush2 = new SolidBrush(Color.Black);//定义黑色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush2, x[i], y[i], 16, 16);
            }
            //移动的内在逻辑
            for (int i = x.Count - 1; i > 0; i--)//除蛇头部分移动
            {
                x[i] = x[i - 1];
                y[i] = y[i - 1];
            }

            x[0] = x[0] - 24;//蛇头移动
            //画出蛇
            SolidBrush brush3 = new SolidBrush(Color.Red);//定义红色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush3, x[i], y[i], 16, 16);
            }
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            //清除蛇
            Graphics g1 = panel1.CreateGraphics();
            SolidBrush brush2 = new SolidBrush(Color.Black);//定义黑色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush2, x[i], y[i], 16, 16);
            }
            //移动的内在逻辑
            for (int i = x.Count - 1; i > 0; i--)//除蛇头部分移动
            {
                x[i] = x[i - 1];
                y[i] = y[i - 1];
            }

            x[0] = x[0] + 24;//蛇头移动
            //画出蛇
            SolidBrush brush3 = new SolidBrush(Color.Red);//定义红色的刷子
            for (int i = 0; i < x.Count; i++)
            {
                g1.FillRectangle(brush3, x[i], y[i], 16, 16);
            }
        }
    }
}
