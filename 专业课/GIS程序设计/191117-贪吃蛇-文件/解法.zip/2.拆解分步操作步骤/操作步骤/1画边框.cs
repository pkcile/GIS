﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 操作步骤
{
    public partial class _1画边框 : Form
    {
        public _1画边框()
        {
            InitializeComponent();
        }

        private void btnBegin_Click(object sender, EventArgs e)
        {
            //将整个框子画出
            Graphics g = panel1.CreateGraphics();//定义画布
            Pen pen1 = new Pen(Color.White, 8);//定义画笔（颜色，粗细）
            for (int i = 0; i <= 16; i++)//代表横线17条线，竖线17条线，形成16*16个格子
            {
                g.DrawLine(pen1, 0, 4 + 24 * i, 392, 4 + 24 * i);//画横线 392=(8+16)*16+8 。 8代表框子的宽度，16代表接下来要定义的格子的宽度
                g.DrawLine(pen1, 4 + 24 * i, 0, 4 + 24 * i, 392);//画竖线
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
