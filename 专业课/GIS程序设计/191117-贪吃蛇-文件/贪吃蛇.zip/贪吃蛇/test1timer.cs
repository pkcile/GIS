﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 贪吃蛇
{
    public partial class test1timer : Form
    {
        public test1timer()
        {
            InitializeComponent();
        }

        private void test1timer_Load(object sender, EventArgs e)
        {
            textBox1.Text = DateTime.Now.ToString("h:mm:ss");
            timer1.Interval = 100;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox1.Text = DateTime.Now.ToString("h:mm:ss");

            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)//开始走
        {
            timer1.Enabled = true;
            left();
         

        }
        public void left()
        {
            label1.Left -= 10;
        }

        private void button2_Click(object sender, EventArgs e)//结束走
        {
            timer1.Enabled = false;

        }
    }
}
